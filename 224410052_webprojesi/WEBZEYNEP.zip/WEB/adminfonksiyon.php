<?php
function adminn(){
    echo '
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="admin.css"/>
        <title>Admin Paneli</title>
    </head>
    <body>
    
        <header>
            <h1>Admin Paneli</h1>
        </header>
    
        <nav>
            <a href="admin.php?konum=1">Günün Menüsü</a>
            <a href="admin.php?konum=2">Tarifler</a>
            <a href="admin.php?konum=3">Tarif Ekle</a>
            <a href="logout.php">Çıkış</a>
            <!-- Daha fazla bağlantı ekleyebilirsiniz -->
        </nav>
    ';
    }
function sayfasonu(){
    echo'    

    </body>
    </html>';
}
function gununmenusu(){
    require_once "baglanti.php";
    $baglanti = baglan();
    $sorgu = "SELECT * FROM gmenu";
    $sonuc = mysqli_query($baglanti,$sorgu);
    echo'
        <table border=1>
        <tr>
            <td>Yemeğin adı</td>
            <td>Yemeğin videosu</td>
            <td>Yemeğin malzemesi</td>
            <td>Yemeğin tarifi</td>
        </tr>';
    while($satir = mysqli_fetch_assoc($sonuc)){
    echo'<tr>
        <td>'.$satir["ADI"].'</td>
        <td>'.$satir["VİDEOSU"].'</td>
        <td>'.$satir["MALZEMESİ"].'</td>
        <td>'.$satir["TARİFİ"].'</td>
        <td><a href="admin.php?id='.$satir["ID"].'&&konum=5" >DÜZENLE</a></td>
    </tr>';
    }
    echo'
    </table>
    </div>';
}
function tarifler(){
    require_once "baglanti.php";
    $baglanti = baglan();
    $sorgu = "SELECT * FROM tarif";
    $sonuc = mysqli_query($baglanti,$sorgu);
    echo'
        <table border=1>
        <tr>
            <td>Yemeğin adı</td>
            <td>Yemeğin videosu</td>
            <td>Yemeğin malzemesi</td>
            <td>Yemeğin tarifi</td>
        </tr>';
    while($satir = mysqli_fetch_assoc($sonuc)){
    echo'<tr>
        <td>'.$satir["ADI"].'</td>
        <td>'.$satir["VİDEOSU"].'</td>
        <td>'.$satir["MALZEMESİ"].'</td>
        <td>'.$satir["TARİFİ"].'</td>
        <td><a href="sil.php?id='.$satir["ID"].'" >SİL</a></td>
        <td><a href="admin.php?id='.$satir["ID"].'&&konum=4" >DÜZENLE</a></td>
    </tr>';
    }
    echo'
    </table>
    </div>';
}
function tarifekle(){
    echo'
    <form action="tarifekle.php" method="post">
        <table>
            <tr>
                <td>Yemeğin Adı</td>
                <td><input type="text" name="adi"></td>
            </tr>
            <tr>
                <td>Yemeğin Videosu</td>
                <td><textarea name="video"></textarea></td>
            </tr>
            <tr>
                <td>Yemeğin Malzemeleri</td>
                <td><textarea name="malzeme"></textarea></td>
            </tr>
            <tr>
                <td>Yemeğin Tarifi</td>
                <td><textarea name="tarif"></textarea></td>
            </tr>

        </table>
        <input type="submit" value="kaydet">
    </form>
    ';
}
function tarifduzenle(){
    require_once "baglanti.php";
    $baglanti = baglan();
    $id = $_GET["id"];
    $sorgu = "SELECT * FROM tarif WHERE ID ='$id'";
    $sonuc = mysqli_query($baglanti,$sorgu);
    $satir = mysqli_fetch_assoc($sonuc);
    $adi =$satir["ADI"];
    $video =$satir["VİDEOSU"];
    $malzeme =$satir["MALZEMESİ"];
    $tarif =$satir["TARİFİ"];
    echo'
    <form action="düzenle.php?id='.$id.'" method="post">
        <table>
            <tr>
                <td>Yemeğin Adı</td>
                <td><input type="text" name="adi" value="'.$adi.'"></td>
            </tr>
            <tr>
                <td>Yemeğin Videosu</td>
                <td><textarea name="video" >'.$video.'</textarea></td>
            </tr>
            <tr>
                <td>Yemeğin Malzemeleri</td>
                <td><textarea name="malzeme" >'.$malzeme.'</textarea></td>
            </tr>
            <tr>
                <td>Yemeğin Tarifi</td>
                <td><textarea name="tarif" >'.$tarif.'</textarea></td>
            </tr>

        </table>
        <input type="submit" value="kaydet">
    </form>
    ';
}
function tarifgduzenle(){
    require_once "baglanti.php";
    $baglanti = baglan();
    $id = $_GET["id"];
    $sorgu = "SELECT * FROM gmenu WHERE ID ='$id'";
    $sonuc = mysqli_query($baglanti,$sorgu);
    $satir = mysqli_fetch_assoc($sonuc);
    $adi =$satir["ADI"];
    $video =$satir["VİDEOSU"];
    $malzeme =$satir["MALZEMESİ"];
    $tarif =$satir["TARİFİ"];
    echo'
    <form action="gmdüzenle.php?id='.$id.'" method="post">
        <table>
            <tr>
                <td>Yemeğin Adı</td>
                <td><input type="text" name="adi" value="'.$adi.'"></td>
            </tr>
            <tr>
                <td>Yemeğin Videosu</td>
                <td><textarea name="video" >'.$video.'</textarea></td>
            </tr>
            <tr>
                <td>Yemeğin Malzemeleri</td>
                <td><textarea name="malzeme" >'.$malzeme.'</textarea></td>
            </tr>
            <tr>
                <td>Yemeğin Tarifi</td>
                <td><textarea name="tarif" >'.$tarif.'</textarea></td>
            </tr>

        </table>
        <input type="submit" value="kaydet">
    </form>
    ';
}
?>