<?php
    session_start();
        $user_name = $_POST["username"];
        $user_password = $_POST["password"];
            if("zeynep" == $user_name && $user_password =="zeynep123"){
                $_SESSION["UserName"]=$user_name;
               header("location:admin.php");
            }
            else{
                header("location:uye.php");
            }
?>