<?php
session_start();
if(isset($_SESSION["UserName"])){
    header("location:admin.php");
}
else{

    echo'
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <link rel="stylesheet" href="uye.css"/>
            <title>Üye Girişi</title>
        </head>
        <body>

            <div class="login-container">
                <h2>Üye Girişi</h2>
                <form class="login-form" action="login.php" method="post">
                    <label for="username">Kullanıcı Adı:</label>
                    <input type="text" id="username" name="username" required>

                    <label for="password">Şifre:</label>
                    <input type="password" id="password" name="password" required>

                    <button type="submit">Giriş Yap</button>
                </form>
            </div>

        </body>
        </html>
        ';

}?>