<?php
require_once "baglanti.php";
$baglanti = baglan();
$id = $_GET["id"];
$sorgu = "SELECT * FROM tarif WHERE ID ='$id'";
$sonuc = mysqli_query($baglanti,$sorgu);
$satir = mysqli_fetch_assoc($sonuc);
if(isset($satir)){
    $id=$_GET["id"];
    $sorgu = "DELETE FROM tarif WHERE ID=$id";
    $sonuc = mysqli_query($baglanti,$sorgu);
    header("location:admin.php?konum=2");
}
else{
    echo "asdkhasdl";
}
?>