<?php
require_once"adminfonksiyon.php";
session_start();
if(isset($_SESSION["UserName"])){
    adminn();
    if(isset ($_GET["konum"])&& 1==($_GET["konum"])){
        gununmenusu();
    }
    elseif(isset ($_GET["konum"])&& 2==($_GET["konum"])){
        tarifler();
    }
    elseif(isset ($_GET["konum"])&& 3==($_GET["konum"])){
        tarifekle();
    }
    elseif(isset ($_GET["konum"])&& 4==($_GET["konum"])){
        tarifduzenle();
    }
    elseif(isset ($_GET["konum"])&& 5==($_GET["konum"])){
        tarifgduzenle();
    }
    sayfasonu();
}
else
header("location:uye.php");
?>