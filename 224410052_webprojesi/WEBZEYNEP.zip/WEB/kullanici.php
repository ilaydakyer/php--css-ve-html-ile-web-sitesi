<?php
require_once"fonksiyonlar.php";
if(isset ($_GET["konum"])&& 3==($_GET["konum"])){
    baslik('tarifler');
    tarifler();
}
elseif(isset ($_GET["konum"])&& 2==($_GET["konum"])){
    baslik('gmenü');
    gmenü();
}
else{
    baslik('web');
    giris();
}

?>