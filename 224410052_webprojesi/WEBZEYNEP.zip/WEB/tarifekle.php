<?php
require_once "baglanti.php";
$baglanti=baglan();
$adi = $_POST["adi"];
$video = $_POST["video"]; 
$malzeme = $_POST["malzeme"]; 
$tarif = $_POST["tarif"]; 
$sorgu ="INSERT INTO `tarif`(`ID`, `ADI`, `VİDEOSU`, `MALZEMESİ`, `TARİFİ`) VALUES ('[value-1]','$adi','$video','$malzeme','$tarif')";
$sonuc=mysqli_query($baglanti,$sorgu);
if($sonuc){
    header("location:admin.php?konum=2");
}else{
    echo "Problem var";
}
?>