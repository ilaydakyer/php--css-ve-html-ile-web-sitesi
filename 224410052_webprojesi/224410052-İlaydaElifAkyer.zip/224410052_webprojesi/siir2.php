<?php
require_once("tema.php");
siirbas("Göğe Bakma Durağı | Turgut Uyar");
siir2();
?>