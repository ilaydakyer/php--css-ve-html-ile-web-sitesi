<?php
require_once("tema.php");
anahead_ustkismi("Anasayfa");
anaorta_kismi();
anaicerik();
?>