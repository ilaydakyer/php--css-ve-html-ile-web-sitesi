<?php
require_once("tema.php");
siirbas("Ne Güzel Şey Hatırlamak Seni|Nazım Hikmet");
siir1();
?>