<?php
require_once("tema.php");
girisbas();
girisyap();
?>