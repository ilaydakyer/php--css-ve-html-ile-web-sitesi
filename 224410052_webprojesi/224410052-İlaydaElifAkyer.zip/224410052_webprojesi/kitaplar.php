<?php
require_once("tema.php");
kitapbas();
kitapadi(); 
?>