<?php
require_once("tema.php");
siirbas("Desem ki | Cahit Sıtkı Tarancı");
siir3();
?>