<?php
require_once("functions.php");
$baglanti= baglan();
$ogr_id=$_GET["id"];
$sorgu = "DELETE FROM ogrenci WHERE ogrenci_id=$ogr_id";
$sonuc = mysqli_query($baglanti,$sorgu);
if($sonuc){
    echo "Kayıt silinmiştir.";
}else{
    echo "Kayıt silinmemiştir.";
}

?>