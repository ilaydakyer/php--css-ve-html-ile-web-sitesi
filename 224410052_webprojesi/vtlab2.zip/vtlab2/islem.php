<?php

require_once "functions.php";
$baglanti = baglan();



$ogr_adi= $_POST["ogr_adi"];
$ogr_soyadi=$_POST["ogr_soyadi"];
$ogr_cinsiyet=$_POST["ogr_cinsiyet"];
$sorgu = "INSERT INTO ogrenci (ogr_adi,ogr_soyadi,ogr_cinsiyet)
VALUES ('$ogr_adi','$ogr_soyadi',$ogr_cinsiyet)  ";
echo $sorgu;
$sonuc = mysqli_query($baglanti,$sorgu);
if($sonuc){
    echo "kayıt başarıyla eklendi";
}else{
    echo "kayıtta problem var";
}


?>