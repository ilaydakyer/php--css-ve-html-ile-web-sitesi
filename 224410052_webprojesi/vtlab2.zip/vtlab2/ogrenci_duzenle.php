<?php
session_start();
require_once "functions.php";
if(isset($_SESSION["kadi"])){
    $baglanti=baglan();
    $ogr_id = $_GET["id"];
    $sorgu = "SELECT * FROM ogrenci WHERE ogr_id=$ogr_id";
    $sonuc = mysqli_query($baglanti,$sorgu);
    $satir = mysqli_fetch_assoc($sonuc);
    $ch1="";
    $ch2="";
    if($satir["ogr_cinsiyet"]==1){
        $ch1="checked";
    }else{
        $ch2="checked";
    }
    echo
    '
    <!DOCTYPE html>
    <html>
    <head>

    </head>
    <body>
    <form action="update.php?id='.$ogr_id.'" method="POST">
    Adı <input type="text" name="ogr_adi" value="'.$satir["ogr_adi"].'" ><br>
    Soyadı <input type="text" name="ogr_soyadi" value="'.$satir["ogr_soyadi"].'"><br>
    Cinsiyet<br>
    Kadın <input type="radio" name="ogr_cinsiyet" value="1" '.$ch1.'><br>
    Erkek <input type="radio" name="ogr_cinsiyet" value="2" '.$ch2.'><br>
    <input type="submit" name="kaydet" value="Kaydet">
    </form> 
    </body>
    </html>
    ';
}else{
    header("location:index.php");
}
?>