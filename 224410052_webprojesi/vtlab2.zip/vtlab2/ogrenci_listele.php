<?php
session_start();
require_once "functions.php";
if(isset($_SESSION["kadi"])){
    echo $_SESSION["kadi"]."<br>";
    echo '<a href="logout.php">Çıkış</a>';
    $baglanti = baglan();
    $sorgu = "SELECT * FROM ogrenci";
    $sonuc = mysqli_query($baglanti,$sorgu);
    if($sonuc){
        echo'
        <table border="1">
        <tr><th>ID</th><th>Adı</th><th>Soyadı</th><th>Cinsiyet</th>
        <th>Düzenle</th><th>Sil</th></tr>
        ';
        while($satir = mysqli_fetch_assoc($sonuc)){
            $cinsiyet="";
            if($satir["ogr_cinsiyet"]==1){
                $cinsiyet="Kadın";
            }else{
                $cinsiyet="Erkek";
            }

            echo "
            <tr>
            <td>".$satir["ogr_id"]."</td>
            <td>".$satir["ogr_adi"]."</td>
            <td>".$satir["ogr_soyadi"]."</td>
            <td>".$cinsiyet.'</td>
            <td><a href="ogrenci_duzenle.php?id='.$satir["ogr_id"].'">Düzenle</a></td>
            <td><a href="ogrenci_sil.php?id='.$satir["ogr_id"].'">Sil</a></td>
            </tr> ';
        }
        echo "</table>";
    }

}else{
    header("location:index.php");
}


?>