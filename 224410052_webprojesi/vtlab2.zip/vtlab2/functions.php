<?php

function baglan(){
    $baglanti = mysqli_connect("localhost","root","","vtlab2");
    if($baglanti){
        //echo "Bağlandık ";
    }else{
        echo "Problem var ";
    }
    return $baglanti;
}
?>