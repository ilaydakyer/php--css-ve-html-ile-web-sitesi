<?php
session_start();
if(isset($_SESSION["kadi"])){
echo'
<!DOCTYPE html>
<html>
<head>

</head>
<body>
<form action="islem.php" method="POST">
Adı <input type="text" name="ogr_adi"><br>
Soyadı <input type="text" name="ogr_soyadi"><br>
Cinsiyet<br>
Kadın <input type="radio" name="ogr_cinsiyet" value="1"><br>
Erkek <input type="radio" name="ogr_cinsiyet" value="2"><br>
 <input type="submit" name="kaydet" value="Kaydet">
</form> 
</body>
</html>';
}else{
    header("location:index.php");
}