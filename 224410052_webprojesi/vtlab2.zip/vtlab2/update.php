<?php
require_once "functions.php";
$baglanti=baglan();
$ogr_id = $_GET["id"];
$ogr_adi = $_POST["ogr_adi"]; 
$ogr_soyadi = $_POST["ogr_soyadi"]; 
$ogr_cinsiyet = $_POST["ogr_cinsiyet"]; 
$sorgu ="UPDATE ogrenci SET 
ogr_adi='$ogr_adi',ogr_soyadi='$ogr_soyadi',ogr_cinsiyet=$ogr_cinsiyet
WHERE ogr_id=$ogr_id";
$sonuc=mysqli_query($baglanti,$sorgu);
if($sonuc){
    header("location:ogrenci_listele.php");
}else{
    echo "Problem var";
}
?>