<!DOCTYPE html>
<html>
<head>

</head>
<body>
<form method="POST" action="login.php">
Kullanıcı Adı<input type="text" name="kadi"><br>
Şifre<input type="password" name="ksifre"><br>
<input type="submit" name="login" value="Giriş">

</form>    
</body>
</html>